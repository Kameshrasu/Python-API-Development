
import mysql.connector


connection = mysql.connector.connect(
 host = "localhost",
 user = "root",
 passwd = "12345678",
 database = "test"
)


print("connection established.........")

def user_detail_insert(firstname , lastname , age , gender):

    user_detail_query = "CREATE TABLE  IF  NOT EXISTS USER_INFO  " \
                        "(ID INT AUTO_INCREMENT PRIMARY KEY ," \
                        " FIRSTNAME TEXT ," \
                        "LASTNAME TEXT ," \
                        "AGE INT ," \
                        "GENDER TEXT);"
    
    cursor = connection.cursor()
    cursor.execute(user_detail_query)
    insert_query = """
    INSERT INTO USER_INFO (FIRSTNAME, LASTNAME, AGE, GENDER)
    VALUES (%s, %s, %s, %s);
    """
    cursor.execute(insert_query,(firstname,lastname,age,gender))
    connection.commit()
    return 200

def user_certificate_info(user_id, certificate_number, certificate_name, file_bytes):
    certificate_table_query = """
    CREATE TABLE IF NOT EXISTS CERTIFICATE_INFO (
        CERT_ID INT AUTO_INCREMENT PRIMARY KEY,
        USER_ID INT,
        CERTIFICATE_NUMBER VARCHAR(50),
        CERTIFICATE_NAME VARCHAR(100),
        CERTIFICATE_FILE LONGBLOB,  -- 👈 store file bytes here
        FOREIGN KEY (USER_ID) REFERENCES USER_INFO(ID)
            ON DELETE CASCADE
            ON UPDATE CASCADE
    );
    """
    cursor = connection.cursor()
    cursor.execute(certificate_table_query)
    insert_query = """
        INSERT INTO CERTIFICATE_INFO (USER_ID, CERTIFICATE_NUMBER, CERTIFICATE_NAME, CERTIFICATE_FILE)
        VALUES (%s, %s, %s, %s)
        """
    cursor.execute(insert_query, (user_id, certificate_number, certificate_name, file_bytes))
    connection.commit()
    return 200





# user_detail_insert("nandhi" , "raja" , 21 , "male")


