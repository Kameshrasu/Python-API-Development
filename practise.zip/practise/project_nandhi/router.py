from fastapi import FastAPI , UploadFile, File, HTTPException , Query , APIRouter
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from service import user_detail_insert , user_certificate_info

router = APIRouter()

class Userinfo(BaseModel):
    firstname : str
    lastname : str
    age : str
    gender : str

class User_certificate:
   USER_ID : int
   CERTIFICATE_NUMBER : int
   CERTIFICATE_NAME : str




@router.post("/insert_user_info")
def insert_user_info(u : Userinfo):
    try:
      code =  user_detail_insert(u.firstname,u.lastname,u.age,u.gender)
      if(code==200):
         return { "message" : "inserted sucessfully"}
    except :
       raise HTTPException( 441 , detail="not inserted sucessfully")
    
@router.post("/user_certificate_info")
def user_certificate(u:User_certificate , file : UploadFile = File(...)):
   try:
       file_bytes =  file.read()
       code=user_certificate_info(u.USER_ID,u.CERTIFICATE_NUMBER,u.CERTIFICATE_NAME,file_bytes)
       if(code==200):
          return {"Message" : "inserted sucessfully"}
   except :
       raise HTTPException( 201 , detail="not inserted sucessfully")
      


