# import mysql.connector
# import requests

# connection = mysql.connector.connect(
#  host = "localhost",
#  user = "root",
#  passwd = "12345678",
#  database = "test"
# )

# cursor  = connection.cursor()
# print("connection established.........")



# table_query = "CREATE TABLE  if not exists USER (" \
# " id int primary key ," \
# "firstname text ," \
# "lastname text ," \
# "age int ," \
# "gender text);"

# cursor.execute(table_query)

# print("table created sucessfully.....")
# try :

#     response = requests.get("https://dummyjson.com/users")
#     data = response.json()
#     print("data fetched..................")
# except Exception as e:
#     print(e)




# values = [(u['id'] , u['firstName'] , u['lastName'] , u['age'] , u['gender']) for u in data['users']]

# insert_query ="INSERT INTO USER(ID,FIRSTNAME,LASTNAME,AGE,GENDER) VALUES(%s,%s,%s,%s,%s) " \
# "on duplicate key update  firstname = values(firstname) , lastname = values(lastname) , age = values(age) , gender = values(gender) "

# cursor.executemany(insert_query , values)
# connection.commit()

# print("values inserted sucessfully")


from fastapi import FastAPI , HTTPException , Query
from fastapi.responses import HTMLResponse
import mysql.connector
from pydantic import BaseModel

connection = mysql.connector.connect(
 host = "localhost",
 user = "root",
 passwd = "12345678",
 database = "test"
)


print("connection established.........")

app = FastAPI()

@app.get("/")
def home():
    return HTMLResponse("<h1>Welcome to my App!</h1>")


@app.get("/get_data")
def get_data(limit : int  = Query(10,ge=1) , offset : int =  Query(0 , ge=0)):
        cursor  = connection.cursor(dictionary=True)
        query = "SELECT * FROM user LIMIT %s OFFSET %s"
       
        try :
            cursor.execute(query, (limit, offset))
            response = cursor.fetchall()
            return response
        except mysql.connector.errors as e:
            raise  HTTPException(500 , detail = e)
        
class User(BaseModel):
    firstname: str
    lastname: str
    age: int
    gender: str
     
@app.post("/insert_data")
def insert_data(user : User):
     cursor  = connection.cursor(dictionary=True)
     query = "INSERT INTO USER VALUES( 4500,%s , %s , %s , %s);"
     cursor.execute(query,(user.firstname,user.lastname,user.age,user.gender))
     return HTMLResponse("<h2 style = color : red>  values inserted sucessfully</h2>")
       






